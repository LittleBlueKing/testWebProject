create trigger trigger_employee
  after UPDATE
  on employee
  for each row
  BEGIN
    insert into employee_log(old_content,new_content) values(old.username,new.username);
    END;

