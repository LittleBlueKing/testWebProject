create function employee_func(aaa varchar(40))
  returns varchar(40)
  BEGIN
    declare aa varchar(40) ;
    ##DECLARE bb VARCHAR(40) ;
    ##set aa = aaa;
    ##set bb = bbb;
    set aa = aaa;
    return aa;
    END;

